const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const mongoose = require("mongoose");

const app = express();
app.set('view engine', 'ejs');

app.use(express.static("public"));     
app.use(bodyParser.urlencoded({extended:true}));
mongoose.connect("mongodb://localhost:27017/couponsDB", {useNewUrlParser: true});
const couponsSchema = {
      name: String,
      amount: Number,
      img_link: String,
      expiryDate: Date,
      couponCode: String
};
const Coupon = mongoose.model("Coupon", couponsSchema);

app.get("/", function(req, res){
    res.redirect("/create");
});

app.get("/create", function(req, res){
    res.sendFile(__dirname + "/createCoupon.html");
});

app.get("/redeem", function(req, res){
    Coupon.find({}, function(err, foundCoupons){
        res.render("displaylistOfCoupons", {coupons: foundCoupons});
      });
});

app.post("/create",function(req, res){
    console.log(req.body.name);
    const newCoupon = new Coupon({
        name: req.body.name,
        amount: req.body.amt,
        img_link: req.body.imgLink,
        expiryDate: req.body.date,
        couponCode: req.body.couponCode
    });
    newCoupon.save();
    res.redirect("/");
    alert("Successfully added");
});

app.listen(3000, function(){
    console.log("Server Started");
});

